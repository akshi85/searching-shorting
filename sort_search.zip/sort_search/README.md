first npm i package install

port start json server : 3005

npm start